using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointSpawner : MonoBehaviour
{
    public GameObject Point;
    public GameObject BigPoint;
    private float spawnRate = 2;
    private float time = 0;
    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        GameObject garfield = GameObject.Find("Garfield");
        anim = garfield.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.isPlaying)
        {
            if (time < spawnRate)
            {
                time += Time.deltaTime;
            }
            else
            {
                int spawnChance = Random.Range(1, 10);
                if (spawnChance < 7)
                {
                    Instantiate(Point, transform.position, transform.rotation);
                }
                else
                {
                    Instantiate(BigPoint, transform.position, transform.rotation);
                }

                time = 0;
                spawnRate = Random.Range(3, 6);
            }
        }
    }
}
