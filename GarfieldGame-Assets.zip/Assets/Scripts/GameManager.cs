using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using UnityEngine.Events;

public class GameManager : MonoBehaviour
{
    #region Singleton 
    
    public static GameManager Instance;

    public void Awake()
    {
        if (Instance == null) Instance = this;
    }

    #endregion

    public static int currentScore = 0;
    [SerializeField] private TextMeshProUGUI scoreUI;
    [SerializeField] public TextMeshProUGUI finalScore;
    [SerializeField] private GameObject startMenuUI;
    [SerializeField] private Button startButton;
    [SerializeField] private Button playAgainButton;
    [SerializeField] private Button quitButton;
    [SerializeField] private GameObject camera;
    [SerializeField] private GameObject mainGarfield;
    [SerializeField] public GameObject dancingGarfield;
    public static float speedBooster;
    public static bool isPlaying = false;
    public UnityEvent onPlay = new UnityEvent();
    // Start is called before the first frame update
    void Start()
    {
        setCameraPosition(-35,0);

        speedBooster = 1f;

        startButton.onClick.AddListener(StartPlaying);
        playAgainButton.onClick.AddListener(StartPlaying);
        quitButton.onClick.AddListener(QuitApp);

    }



    // Update is called once per frame
    void Update()
    {
        scoreUI.text = currentScore.ToString();
        if (isPlaying)
        {
            speedBooster += (Time.deltaTime / 40);
        }

    }

    private void QuitApp()
    {
        Application.Quit();
    }

    private void StartPlaying()
    {

        isPlaying = true;

        setCameraPosition(0,0);

        startMenuUI.SetActive(false);
        mainGarfield.SetActive(true);
        dancingGarfield.SetActive(false);

    }

    public void setCameraPosition(int x, int y)
    {
       camera.transform.position = new Vector3(x, y, -10);
    }
}
