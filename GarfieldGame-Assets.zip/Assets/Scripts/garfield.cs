using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class garfield : MonoBehaviour
{
    private Rigidbody2D body;
    private Animator anim;
    private bool jump;
    private float timeAlive;
    private float jumppower = 20;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.isPlaying)
        {
            timeAlive += Time.deltaTime;

            if (timeAlive > 5)
            {
                body.gravityScale += 0.1f;
                jumppower += 0.05f;
                timeAlive = 0;

            }

            if (Input.GetKeyDown(KeyCode.Space) == true && !anim.GetBool("hit"))
            {
                if (!jump)
                {
                    body.velocity = new Vector2(body.velocity.x, jumppower);
                    jump = true;
                }
            }


            anim.SetBool("jump", jump);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            jump = false;
        }

        if (collision.gameObject.tag == "Spike")
        {
            StartCoroutine(GameOver());
        }
    }

    IEnumerator GameOver()
    {
        anim.SetBool("hit", true);

        //Wait for 4 seconds
        yield return new WaitForSeconds(2);

        gameObject.SetActive(false);

        GameManager.isPlaying = false;
        GameManager.Instance.setCameraPosition(35, 0);
        GameManager.Instance.dancingGarfield.SetActive(true);
        GameManager.Instance.finalScore.text = GameManager.currentScore.ToString();
        GameManager.currentScore = 0;
        GameManager.speedBooster = 1;
        body.gravityScale = 5;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Point")
        {
            GameManager.currentScore += 1;
        }

        if (collision.gameObject.tag == "BigPoint")
        {
            GameManager.currentScore += 5;
        }
    }
}
