using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class background : MonoBehaviour
{
    public float speed;
    private Animator anim;

    [SerializeField] private Renderer bgRenderer;
    void Start()
    {
        GameObject garfield = GameObject.Find("Garfield");
        anim = garfield.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!anim.GetBool("hit"))
        {
            bgRenderer.material.mainTextureOffset += new Vector2(speed * Time.deltaTime, 0);
        }
    }
}
