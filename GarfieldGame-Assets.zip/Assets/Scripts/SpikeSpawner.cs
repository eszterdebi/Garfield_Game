using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpikeSpawner : MonoBehaviour
{
    public GameObject Spike;
    private float spawnRate = 1;
    private float time = 0;
    private Animator anim;

    void Start()
    {
        GameObject garfield = GameObject.Find("Garfield");
        anim = garfield.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.isPlaying)
        {
            if (time < spawnRate)
            {
                time += Time.deltaTime * GameManager.speedBooster;
            }
            else
            {
                Instantiate(Spike, transform.position, transform.rotation);
                time = 0;

                spawnRate = Random.Range(2, 4);
            }
        }
    }
}
