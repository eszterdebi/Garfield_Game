using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spikes : MonoBehaviour
{
    public float movespeed = 5f;
    public float deadZone = -20;
    private Animator anim;
    

    // Start is called before the first frame update
    void Start()
    {
        GameObject garfield = GameObject.Find("Garfield");
        anim = garfield.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        

        if (transform.position.x < deadZone)
        {
            Destroy(gameObject);
        }

        if (!anim.GetBool("hit"))
        {
            transform.position = transform.position + (Vector3.left * movespeed * GameManager.speedBooster) * Time.deltaTime;
        }else
        {
            StartCoroutine(DestroyEverything());
        }
    }

    IEnumerator DestroyEverything()
    {
        yield return new WaitForSeconds(1.8f);

        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Garfield")
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Garfield")
        {
            Destroy(gameObject);
        }
    }
}
